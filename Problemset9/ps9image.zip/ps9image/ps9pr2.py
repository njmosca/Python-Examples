#
# ps9pr2.py (Problem Set 9, Problem 2)
#
# Image processing with loops and image objects
#
# Computer Science 111
# 

from cs111png import *

